extern	BYTE		keytab[256];
extern	HDC			hdc;
extern	HWND		hWndGlobal;
extern	HGLRC		hrc;
