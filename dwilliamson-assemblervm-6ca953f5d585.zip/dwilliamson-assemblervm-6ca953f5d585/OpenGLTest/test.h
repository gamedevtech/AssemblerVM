extern	void	MainLoop(void);
extern	void	EndFunction(void);
extern	void	StartFunction(void);
