
extern	int		GLPixelIndex;

extern	BOOL	SetWindowPixelFormat(HDC hdc);
extern	void	EnableOpenGL(HWND hWnd, HDC *hdc, HGLRC * hrc);
extern	void	DisableOpenGL(HWND hWnd, HDC hdc, HGLRC hrc);
